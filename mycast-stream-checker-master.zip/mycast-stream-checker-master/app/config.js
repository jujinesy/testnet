"use strict";

/**
 * 기본 포트값을 나타냅니다.
 * @type {number}
 */
exports.defaultPort = 9000;